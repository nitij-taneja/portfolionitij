import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { PersonalStory } from "@/components/PersonalStory";
import { Experience } from "@/components/Experience";
import { Projects } from "@/components/Projects";
import { Skills } from "@/components/Skills";
import { SocialMedia } from "@/components/SocialMedia";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <About />
        <PersonalStory />
        <Experience />
        <Projects />
        <Skills />
        <SocialMedia />
        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
