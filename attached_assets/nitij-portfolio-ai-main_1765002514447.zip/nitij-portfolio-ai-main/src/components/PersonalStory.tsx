import { Card, CardContent } from "@/components/ui/card"

export function PersonalStory() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">My Journey</h2>
            <p className="text-lg text-muted-foreground">
              From curiosity to building AI solutions that matter
            </p>
          </div>

          <Card className="bg-gradient-card border-0 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-8 space-y-6 text-muted-foreground text-lg leading-relaxed">
              <p>
                I'm Nitij Taneja, a 3rd-year Integrated M.Tech student at VIT Bhopal. I'm curious about how data and AI can transform the world, especially in the financial space.
              </p>

              <p>
                My journey in data science began with a curiosity about how data can drive decisions and solve complex problems. Over time, I've honed my skills in Python, SQL, R, and statistical analysis, learning to build machine learning and deep learning models to address real-world challenges.
              </p>

              <p>
                As I dive deeper into the intersection of data science and finance, I'm particularly fascinated by how advanced analytics can transform financial systems, optimize decision-making, and uncover insights that drive growth. I'm also exploring the potential of generative AI, LLMs, NLP, and computer vision to enhance financial forecasting, risk analysis, and personalized financial services.
              </p>

              <p>
                In my ongoing journey, I've worked on some exciting projects like building a social media platform inspired by Twitter and developing an AI-powered accounting tool. I've also been a go-to person for helping others with data science and coding concepts, which naturally led me to start a YouTube channel called <strong className="text-primary">Data Science Insights</strong>. The idea was simple: teach data science in short, interactive one-minute videos. It's on pause now, but the vision is still alive.
              </p>

              <p>
                Outside academics, I've done things that push me beyond my comfort zone like scuba diving, trekking, and even jet skiing. I enjoy challenges, whether it's debugging code or exploring the unknown underwater.
              </p>

              <p>
                Beyond the technical aspects, I'm passionate about using data to create practical solutions that have a positive impact on business and society. Whether it's through improving safety, optimizing processes, or providing actionable financial insights, I'm always looking for ways to contribute meaningfully.
              </p>

              <p className="text-primary font-medium">
                These days, I'm especially interested in exploring how AI can reshape finance through smarter decisions, better predictions, and more accessible tools. I'm not just here to build models — I want to build things that matter.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}