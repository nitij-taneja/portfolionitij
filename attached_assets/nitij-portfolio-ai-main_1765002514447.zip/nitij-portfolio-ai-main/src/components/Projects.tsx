import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Github, ExternalLink, Play, Code, Lightbulb, Target } from "lucide-react"
import { useState } from "react"

export function Projects() {
  const [selectedCategory, setSelectedCategory] = useState("all")

  // CONFIGURATION: Update project links and add images here
  const projects = [
    {
      title: "Research Paper Classification and Journal Recommendation",
      description: "NLP-based classification system that analyzes academic research papers for publishability using features like readability metrics, sentiment polarity, and topic coherence.",
      category: "machine-learning",
      technologies: ["Python", "Scikit-learn", "NLTK", "spaCy", "PyPDF2", "Sentence Transformers"],
      highlights: [
        "Automated publishability classification with high accuracy",
        "Semantic matching to relevant academic venues",
        "PDF processing and text extraction pipeline",
        "Machine learning feature engineering"
      ],
      github: "https://github.com/nitij-taneja/Research-Papers-Classification",
      demo: "#", // Demo coming soon
      video: "/src/assets/research-paper-video.mp4", // Project video
      image: "/api/placeholder/400/250" // TODO: Replace with project image
    },
    {
      title: "SmartShop.ai - AI-Enhanced E-Commerce",
      description: "Full-stack AI-integrated e-commerce solution with intelligent product discovery, chatbot assistance, and real-time price negotiation using Together AI.",
      category: "full-stack",
      technologies: ["FastAPI", "Streamlit", "Together AI", "Pandas", "Python"],
      highlights: [
        "AI-powered chatbot for product recommendations",
        "Smart bargaining system with price negotiation",
        "Similarity-based recommendation engine", 
        "Responsive frontend with modern UI"
      ],
      github: "https://github.com/nitij-taneja/SmartShop.ai",
      demo: "#", // Demo coming soon
      video: "#", // Video coming soon
      image: "/src/assets/smartshop-project.jpg"
    },
    {
      title: "SafeSphere - Community Safety Risk Modeling",
      description: "Commuter safety risk assessment framework using hybrid CNN-LSTM model for spatial-temporal analysis with interactive map visualization.",
      category: "machine-learning",
      technologies: ["Python", "FastAPI", "Streamlit", "Scikit-learn", "Folium", "GeoPy"],
      highlights: [
        "Hybrid CNN-LSTM for spatial-temporal modeling",
        "Real-time risk assessment and alerts",
        "Interactive map-based risk visualization",
        "Proximity-based safety scoring system"
      ],
      github: "https://github.com/nitij-taneja/SafeSphere",
      demo: "#", // Demo coming soon
      video: "#", // Video coming soon
      image: "/src/assets/safesphere-project.jpg"
    },
    {
      title: "Bitcoin Price Prediction & Trading Strategy",
      description: "Crypto trading model using Random Forest, PCA, and autocorrelation-based features with comprehensive backtesting and risk management.",
      category: "data-science",
      technologies: ["Python", "Pandas", "Scikit-learn", "Statsmodels", "Matplotlib", "Seaborn"],
      highlights: [
        "Advanced feature engineering with PCA",
        "Autocorrelation-based trading signals",
        "Comprehensive backtesting framework",
        "Risk metrics and performance analysis"
      ],
      github: "https://github.com/nitij-taneja/bitcoin-trading-strategy",
      demo: "#", // Demo coming soon
      video: "#", // Video coming soon
      image: "/src/assets/bitcoin-project.jpg"
    }
  ]

  const categories = [
    { id: "all", label: "All Projects" },
    { id: "machine-learning", label: "Machine Learning" },
    { id: "full-stack", label: "Full Stack" },
    { id: "data-science", label: "Data Science" }
  ]

  const filteredProjects = selectedCategory === "all" 
    ? projects 
    : projects.filter(project => project.category === selectedCategory)

  return (
    <section id="projects" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Featured Projects</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A showcase of my work in AI, machine learning, and full-stack development
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              onClick={() => setSelectedCategory(category.id)}
              className="transition-all duration-300"
            >
              {category.label}
            </Button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto items-start">
          {filteredProjects.map((project, index) => (
            <Card 
              key={index}
              className="bg-gradient-card border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group h-full flex flex-col"
            >
              {/* Project Image */}
              <div className="relative h-48 bg-gradient-primary/10 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-primary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute top-4 right-4 space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button size="sm" variant="secondary" className="h-8 w-8 p-0">
                    <Github size={14} />
                  </Button>
                  <Button size="sm" variant="secondary" className="h-8 w-8 p-0">
                    <ExternalLink size={14} />
                  </Button>
                  <Button size="sm" variant="secondary" className="h-8 w-8 p-0">
                    <Play size={14} />
                  </Button>
                </div>
                {/* Placeholder for project image */}
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.nextElementSibling?.classList.remove('hidden');
                  }}
                />
                <div className="hidden w-full h-full flex items-center justify-center text-muted-foreground">
                  <Code size={48} />
                </div>
              </div>

              <CardHeader className="pb-4">
                <CardTitle className="text-xl group-hover:text-primary transition-colors">
                  {project.title}
                </CardTitle>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {project.description}
                </p>
              </CardHeader>

              <CardContent className="space-y-6 flex-1 flex flex-col">
                {/* Key Features */}
                <div>
                  <h4 className="font-semibold mb-3 flex items-center space-x-2">
                    <Lightbulb size={16} className="text-primary" />
                    <span>Key Features</span>
                  </h4>
                  <ul className="space-y-1">
                    {project.highlights.slice(0, 3).map((highlight, idx) => (
                      <li key={idx} className="flex items-start space-x-2 text-sm">
                        <Target size={12} className="text-primary mt-1 flex-shrink-0" />
                        <span className="text-muted-foreground">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Technologies */}
                <div>
                  <h4 className="font-semibold mb-3">Technologies</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, idx) => (
                      <Badge 
                        key={idx} 
                        variant="secondary"
                        className="text-xs bg-primary/10 text-primary border-primary/20"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-3 pt-4 border-t mt-auto">
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="flex-1"
                    onClick={() => window.open(project.github, '_blank')}
                  >
                    <Github size={14} className="mr-2" />
                    Code
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="flex-1"
                     onClick={() => project.demo === "#" ? null : window.open(project.demo, '_blank')}
                     disabled={project.demo === "#"}
                  >
                    <ExternalLink size={14} className="mr-2" />
                    {project.demo === "#" ? "Coming Soon" : "Demo"}
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="flex-1"
                    onClick={() => project.video === "#" ? null : window.open(project.video, '_blank')}
                    disabled={project.video === "#"}
                  >
                    <Play size={14} className="mr-2" />
                    {project.video === "#" ? "Coming Soon" : "Video"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}