import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { GraduationCap, Award, Calendar, MapPin } from "lucide-react"

export function About() {
  return (
    <section id="about" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">About Me</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            I'm an undergraduate student at VIT Bhopal, deeply passionate about Data Science and Finance. 
            Currently working as an AI Developer at Msarii in Dubai, helping integrate AI solutions 
            and training developers while exploring the intersection of data science and finance.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Education Card */}
          <Card className="bg-gradient-card border-0 shadow-lg hover:shadow-xl card-3d">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <GraduationCap className="text-primary" size={24} />
                <span>Education</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Current Education */}
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <img 
                      src="/api/placeholder/64/64" 
                      alt="VIT Bhopal" 
                      className="w-12 h-12 object-contain"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.nextElementSibling?.classList.remove('hidden');
                      }}
                    />
                    <div className="hidden w-12 h-12 bg-primary/20 rounded flex items-center justify-center text-xs font-bold text-primary">
                      VIT
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-lg">Integrated M.Tech (B.Tech + M.Tech Program)</h3>
                        <p className="text-primary font-medium">Computer Science and Engineering</p>
                        <p className="text-sm text-muted-foreground">
                          Specialization: Data Science and Computational Thinking
                        </p>
                        <div className="flex items-center space-x-2 mt-2">
                          <MapPin size={14} className="text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">VIT Bhopal University, Bhopal</span>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-success/10 text-success border-success/20">
                        CGPA: 8.56
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground mt-2">
                      <Calendar size={14} />
                      <span>2022 – 2027 (Ongoing)</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6 space-y-4">
                {/* Senior Secondary */}
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-lg bg-warning/10 flex items-center justify-center flex-shrink-0">
                    <img 
                      src="/api/placeholder/48/48" 
                      alt="Apex International School" 
                      className="w-8 h-8 object-contain"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.nextElementSibling?.classList.remove('hidden');
                      }}
                    />
                    <div className="hidden w-8 h-8 bg-warning/20 rounded flex items-center justify-center text-xs font-bold text-warning">
                      AIS
                    </div>
                  </div>
                  <div className="flex-1 flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Senior Secondary School</h4>
                      <p className="text-sm text-muted-foreground">Apex International School, Jaipur • CBSE (2022)</p>
                    </div>
                    <Badge variant="outline">77.6%</Badge>
                  </div>
                </div>

                {/* Secondary */}
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <img 
                      src="/api/placeholder/48/48" 
                      alt="U.C.S.K.M Public School" 
                      className="w-8 h-8 object-contain"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.nextElementSibling?.classList.remove('hidden');
                      }}
                    />
                    <div className="hidden w-8 h-8 bg-accent/20 rounded flex items-center justify-center text-xs font-bold text-accent">
                      UPS
                    </div>
                  </div>
                  <div className="flex-1 flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Secondary School</h4>
                      <p className="text-sm text-muted-foreground">U.C.S.K.M Public School, Bhiwadi • CBSE (2020)</p>
                    </div>
                    <Badge variant="outline">91%</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Achievements & Certifications Card */}
          <Card className="bg-gradient-card border-0 shadow-lg hover:shadow-xl card-3d">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Award className="text-primary" size={24} />
                <span>Achievements & Certifications</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-3 bg-primary/5 rounded-lg border border-primary/10">
                  <h4 className="font-semibold text-sm">🏆 Stock Quest Winner</h4>
                  <p className="text-xs text-muted-foreground">
                    Led team to 1st place among 40 teams at VIT Bhopal
                  </p>
                </div>

                <div className="p-3 bg-warning/5 rounded-lg border border-warning/10">
                  <h4 className="font-semibold text-sm">🚀 IIT Kharagpur Hackathon</h4>
                  <p className="text-xs text-muted-foreground">
                    Cleared two rounds among 10k+ participants
                  </p>
                </div>

                <div className="p-3 bg-success/5 rounded-lg border border-success/10">
                  <h4 className="font-semibold text-sm">⚡ AWS ML Challenge</h4>
                  <p className="text-xs text-muted-foreground">
                    Team Leader - Rank 23 in Top 50 teams
                  </p>
                </div>

                <div className="space-y-2 pt-2">
                  <h5 className="font-medium text-sm">Certifications:</h5>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="text-xs">Applied ML - UMichigan</Badge>
                    <Badge variant="outline" className="text-xs">Data Science Masters</Badge>
                    <Badge variant="outline" className="text-xs">Business Analytics</Badge>
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <h5 className="font-medium text-sm">HackerRank Badges:</h5>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="text-xs bg-warning/10 text-warning">Python Gold</Badge>
                    <Badge variant="secondary" className="text-xs bg-warning/10 text-warning">SQL Gold</Badge>
                    <Badge variant="secondary" className="text-xs bg-warning/10 text-warning">C Gold</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}