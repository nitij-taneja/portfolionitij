import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, TrendingUp, Users, Code, BookOpen } from "lucide-react"

export function Experience() {
  // CONFIGURATION: Update these as needed
  const experiences = [
    {
      company: "Blue Briar Consultancy OPC Pvt Ltd",
      position: "Jr Data Scientist",
      location: "Remote",
      duration: "July 2024 – Present",
      type: "current",
      logo: "/src/assets/msarii-logo.png", // TODO: Add Blue Briar logo
      highlights: [
        "Creating comprehensive training materials for Langchain and Crew AI frameworks",
        "Developing and testing prototypes for various AI-driven solutions",
        "Building voice calling agent systems with STT (Speech-to-Text) and TTS (Text-to-Speech) integration",
        "Implementing multi-agent orchestration prototypes for complex AI workflows",
        "Working with Google SDK and various AI APIs for enhanced functionality",
        "Researching and implementing cutting-edge AI technologies for business solutions"
      ],
      skills: ["Langchain", "Crew AI", "Voice AI", "STT/TTS", "Multi-Agent Systems", "Google SDK", "Prototyping"]
    },
    {
      company: "ApexIQ AI Solutions and Innovations Pvt Ltd",
      position: "Data Science Intern → Project Head (Backend Developer)",
      location: "Remote",
      duration: "Oct 2023 – June 2024",
      type: "past",
      logo: "/src/assets/apexiq-logo.jpg",
      highlights: [
        "Promoted to Project Head; led backend development across multiple AI-driven products",
        "Worked on VyasaIQ project (https://www.apexiq.ai/VyasaIq)",
        "Developed PostCallAnalytics solutions (https://www.apexiq.ai/PostCallAnalytics)",
        "Contributed to CitizenU platform development",
        "Built end-to-end audio-to-appointment automation pipeline using FastAPI, Whisper, Mixtral (LLM)",
        "Supervised and mentored a team of 2 interns with task delegation and code reviews",
        "Developed modular Django REST APIs for learning management system"
      ],
      skills: ["FastAPI", "Django", "Whisper", "Mixtral LLM", "Team Leadership", "REST APIs"]
    },
    {
      company: "CloudyML E-Learning Pvt Ltd",
      position: "Data Science Intern",
      location: "Remote", 
      duration: "Dec 2023 – Mar 2024",
      type: "past",
      logo: "/src/assets/cloudyml-logo.jpg",
      highlights: [
        "Provided technical mentorship to 100+ learners on ML, DL, and NLP concepts",
        "Conducted interactive Zoom sessions for doubt resolution and project guidance",
        "Created educational video tutorials and blog content for ML topics",
        "Supported career-switching professionals from Infosys, TCS transitioning to data science",
        "Guided students through deployment workflows and practical implementations"
      ],
      skills: ["Machine Learning", "Deep Learning", "NLP", "Mentoring", "Technical Writing"]
    }
  ]

  return (
    <section id="experience" className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Work Experience</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Professional journey in data science, AI development, and technical leadership
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          {experiences.map((exp, index) => (
            <Card 
              key={index}
              className={`border-0 shadow-lg hover:shadow-xl card-3d relative overflow-hidden ${
                exp.type === 'current' 
                  ? 'bg-gradient-primary/5 border-l-4 border-l-primary' 
                  : 'bg-gradient-card'
              }`}
            >
              {exp.type === 'current' && (
                <div className="absolute top-4 right-4">
                  <Badge className="bg-primary text-primary-foreground">
                    Current
                  </Badge>
                </div>
              )}

              <CardHeader className="pb-4">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                      <img 
                        src={exp.logo} 
                        alt={`${exp.company} logo`} 
                        className="w-8 h-8 object-contain"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                          e.currentTarget.nextElementSibling?.classList.remove('hidden');
                        }}
                      />
                      <div className="hidden w-8 h-8 bg-primary/20 rounded flex items-center justify-center text-xs font-bold text-primary">
                        {exp.company.split(' ').map(word => word[0]).join('').slice(0, 2)}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <CardTitle className="text-xl">{exp.position}</CardTitle>
                      <h3 className="text-lg font-semibold text-primary">{exp.company}</h3>
                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <MapPin size={14} />
                          <span>{exp.location}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Calendar size={14} />
                          <span>{exp.duration}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {exp.type === 'current' ? (
                      <TrendingUp className="text-success" size={20} />
                    ) : (
                      <BookOpen className="text-muted-foreground" size={20} />
                    )}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Key Highlights */}
                <div>
                  <h4 className="font-semibold mb-3 flex items-center space-x-2">
                    <Users size={16} className="text-primary" />
                    <span>Key Achievements</span>
                  </h4>
                  <ul className="space-y-2">
                    {exp.highlights.map((highlight, idx) => (
                      <li key={idx} className="flex items-start space-x-2 text-sm">
                        <span className="text-primary mt-1">•</span>
                        <span className="text-muted-foreground">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Technologies */}
                <div>
                  <h4 className="font-semibold mb-3 flex items-center space-x-2">
                    <Code size={16} className="text-primary" />
                    <span>Technologies & Skills</span>
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {exp.skills.map((skill, idx) => (
                      <Badge 
                        key={idx} 
                        variant="secondary"
                        className="text-xs bg-primary/10 text-primary border-primary/20"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}