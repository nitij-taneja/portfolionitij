import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  Mail, Phone, MapPin, Github, Linkedin, Instagram, Youtube, 
  ExternalLink, Trophy, FileText, Award, Code
} from "lucide-react"

export function Contact() {
  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "tanejanitij4002@gmail.com",
      href: "mailto:tanejanitij4002@gmail.com"
    },
    {
      icon: Phone,
      label: "Phone",
      value: "+91-7023108081",
      href: "tel:+917023108081"
    },
    {
      icon: MapPin,
      label: "Location",
      value: "Bhiwadi, Rajasthan, India",
      href: "#"
    }
  ]

  const socialProfiles = [
    {
      name: "GitHub",
      icon: Github,
      href: "https://github.com/nitij-taneja",
      color: "hover:text-gray-900 dark:hover:text-gray-100",
      description: "Code repositories and projects"
    },
    {
      name: "LinkedIn", 
      icon: Linkedin,
      href: "https://www.linkedin.com/in/nitij-taneja-702645204/",
      color: "hover:text-blue-600",
      description: "Professional network"
    },
    {
      name: "Instagram",
      icon: Instagram,
      href: "https://www.instagram.com/data_scienceinsights",
      color: "hover:text-pink-600",
      description: "Data Science content (5k+ views)"
    },
    {
      name: "YouTube",
      icon: Youtube,
      href: "https://youtube.com/@data_science_insights",
      color: "hover:text-red-600",
      description: "Educational videos"
    }
  ]

  const achievements = [
    {
      platform: "HackerRank",
      icon: Code,
      badges: ["Python Gold", "SQL Gold", "C Gold"],
      href: "#",
      color: "text-green-600"
    },
    {
      platform: "HackerEarth",
      icon: Trophy,
      badges: ["Algorithm Arena - Top Rank"],
      href: "https://drive.google.com/file/d/1rJacglSXtzu5B1_JKVPORrEfuTBqmw1n/view?usp=drivesdk",
      color: "text-blue-600"
    }
  ]

  const certifications = [
    {
      title: "Applied Machine Learning in Python",
      issuer: "University of Michigan (Coursera)",
      href: "#",
      date: "Dec 2023"
    },
    {
      title: "Data Science Masters",
      issuer: "PWSkills",
      href: "https://pwskills.com/learn/certificate/3c2bcd5a-0130-456c-9042-5ea84a160e55/",
      date: "2023"
    },
    {
      title: "Business Analytics Foundations",
      issuer: "PWSkills", 
      href: "#",
      date: "2023"
    }
  ]

  return (
    <section id="contact" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Get In Touch</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Let's connect and discuss opportunities in data science, AI, and technology
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Contact Information */}
          <Card className="lg:col-span-1 bg-gradient-card border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {contactInfo.map((contact, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <contact.icon className="text-primary" size={20} />
                  </div>
                  <div>
                    <p className="font-medium text-sm">{contact.label}</p>
                    {contact.href !== "#" ? (
                      <a 
                        href={contact.href}
                        className="text-muted-foreground hover:text-primary transition-colors text-sm"
                      >
                        {contact.value}
                      </a>
                    ) : (
                      <p className="text-muted-foreground text-sm">{contact.value}</p>
                    )}
                  </div>
                </div>
              ))}

              {/* Quick Contact Buttons */}
              <div className="pt-6 space-y-3">
                <Button 
                  className="w-full bg-gradient-primary hover:shadow-glow transition-all duration-300"
                  onClick={() => window.open("mailto:tanejanitij4002@gmail.com", "_blank")}
                >
                  <Mail className="mr-2" size={18} />
                  Send Email
                </Button>
                <Button 
                  variant="outline"
                  className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                  onClick={() => window.open("https://www.linkedin.com/in/nitij-taneja-702645204/", "_blank")}
                >
                  <Linkedin className="mr-2" size={18} />
                  Connect on LinkedIn
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Social Profiles & Achievements */}
          <div className="lg:col-span-2 space-y-8">
            {/* Social Media */}
            <Card className="bg-gradient-card border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Social Profiles & Content</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 gap-4">
                  {socialProfiles.map((social, index) => (
                    <a
                      key={index}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-4 border border-border rounded-lg hover:border-primary transition-all duration-300 group"
                    >
                      <div className="flex items-center space-x-3">
                        <social.icon 
                          className={`text-muted-foreground ${social.color} transition-colors`} 
                          size={24} 
                        />
                        <div>
                          <h4 className="font-medium group-hover:text-primary transition-colors">
                            {social.name}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            {social.description}
                          </p>
                        </div>
                      </div>
                    </a>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Achievements & Certifications */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Platform Achievements */}
              <Card className="bg-gradient-card border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg">Platform Achievements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {achievements.map((achievement, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <achievement.icon className={achievement.color} size={20} />
                          <span className="font-medium">{achievement.platform}</span>
                        </div>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => window.open(achievement.href, "_blank")}
                        >
                          <ExternalLink size={14} />
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {achievement.badges.map((badge, idx) => (
                          <Badge 
                            key={idx} 
                            variant="secondary"
                            className="text-xs bg-warning/10 text-warning border-warning/20"
                          >
                            {badge}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Certifications */}
              <Card className="bg-gradient-card border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg">Certifications</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {certifications.map((cert, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <h4 className="font-medium text-sm">{cert.title}</h4>
                          <p className="text-xs text-muted-foreground">{cert.issuer}</p>
                          <p className="text-xs text-muted-foreground">{cert.date}</p>
                        </div>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => window.open(cert.href, "_blank")}
                        >
                          <FileText size={14} />
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Research & Publications */}
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="text-primary" size={20} />
                  <span>Research & Publications</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-background/50 rounded-lg">
                    <h4 className="font-medium text-sm mb-1">
                      Spatial-Temporal Data Research Papers
                    </h4>
                    <p className="text-xs text-muted-foreground mb-2">
                      Under Dr. Sayed Mohammed Zeeshan • Currently under review
                    </p>
                    <Badge variant="outline" className="text-xs">
                      Co-authored 2 papers
                    </Badge>
                  </div>
                  <div className="p-3 bg-background/50 rounded-lg">
                    <h4 className="font-medium text-sm mb-1">
                      Technical Blog Writing
                    </h4>
                    <p className="text-xs text-muted-foreground mb-2">
                      Published articles on ML, NLP, and RAG workflows
                    </p>
                    <div className="flex gap-2">
                      <Badge variant="outline" className="text-xs">Medium</Badge>
                      <Badge variant="outline" className="text-xs">Company Blogs</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}