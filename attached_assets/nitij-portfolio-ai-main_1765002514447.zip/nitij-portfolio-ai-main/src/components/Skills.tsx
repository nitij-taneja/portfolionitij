import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Code, Database, Brain, Wrench, Cloud, BookOpen } from "lucide-react"

export function Skills() {
  const skillCategories = [
    {
      title: "Programming Languages",
      icon: Code,
      color: "text-blue-500",
      skills: [
        { name: "Python", level: 95, category: "expert" },
        { name: "SQL", level: 90, category: "expert" },
        { name: "R", level: 75, category: "intermediate" },
        { name: "C++", level: 60, category: "basic" },
        { name: "Java", level: 55, category: "basic" }
      ]
    },
    {
      title: "Machine Learning & AI",
      icon: Brain,
      color: "text-purple-500",
      skills: [
        { name: "Deep Learning", level: 90, category: "expert" },
        { name: "NLP", level: 85, category: "expert" },
        { name: "Computer Vision", level: 80, category: "intermediate" },
        { name: "Time Series", level: 75, category: "intermediate" },
        { name: "MLOps", level: 70, category: "intermediate" }
      ]
    },
    {
      title: "Frameworks & Libraries",
      icon: Wrench,
      color: "text-green-500",
      skills: [
        { name: "PyTorch", level: 85, category: "expert" },
        { name: "TensorFlow", level: 80, category: "intermediate" },
        { name: "FastAPI", level: 90, category: "expert" },
        { name: "Django", level: 85, category: "expert" },
        { name: "Streamlit", level: 90, category: "expert" },
        { name: "Langchain", level: 75, category: "intermediate" },
        { name: "Crew AI", level: 70, category: "intermediate" }
      ]
    },
    {
      title: "Data & Databases",
      icon: Database,
      color: "text-orange-500",
      skills: [
        { name: "Pandas", level: 95, category: "expert" },
        { name: "MongoDB", level: 75, category: "intermediate" },
        { name: "PostgreSQL", level: 80, category: "intermediate" },
        { name: "Firebase", level: 70, category: "intermediate" },
        { name: "PowerBI", level: 75, category: "intermediate" }
      ]
    },
    {
      title: "Tools & DevOps",
      icon: Cloud,
      color: "text-red-500",
      skills: [
        { name: "Docker", level: 75, category: "intermediate" },
        { name: "Git/GitHub", level: 90, category: "expert" },
        { name: "GitHub Actions", level: 80, category: "intermediate" },
        { name: "MLflow", level: 70, category: "intermediate" },
        { name: "Postman", level: 85, category: "expert" },
        { name: "Google SDK", level: 65, category: "intermediate" },
        { name: "AWS", level: 45, category: "basic" }
      ]
    },
    {
      title: "Specialized Skills",
      icon: BookOpen,
      color: "text-indigo-500",
      skills: [
        { name: "API Development", level: 90, category: "expert" },
        { name: "LLMs & Transformers", level: 85, category: "expert" },
        { name: "Recommender Systems", level: 80, category: "intermediate" },
        { name: "PDF Processing", level: 85, category: "expert" },
        { name: "Deployment", level: 80, category: "intermediate" }
      ]
    }
  ]

  const getLevelColor = (level: number) => {
    if (level >= 85) return "bg-success"
    if (level >= 70) return "bg-warning"
    return "bg-primary"
  }

  const getCategoryBadge = (category: string) => {
    const variants = {
      expert: "bg-success/10 text-success border-success/20",
      intermediate: "bg-warning/10 text-warning border-warning/20", 
      basic: "bg-primary/10 text-primary border-primary/20"
    }
    return variants[category as keyof typeof variants] || variants.basic
  }

  return (
    <section id="skills" className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Technical Skills</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive expertise across the data science and AI development stack
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {skillCategories.map((category, index) => (
            <Card 
              key={index}
              className="bg-gradient-card border-0 shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center space-x-3">
                  <category.icon className={`${category.color}`} size={24} />
                  <span className="text-lg">{category.title}</span>
                </CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{skill.name}</span>
                      <Badge 
                        variant="outline"
                        className={`text-xs ${getCategoryBadge(skill.category)}`}
                      >
                        {skill.category}
                      </Badge>
                    </div>
                    <div className="space-y-1">
                      <Progress 
                        value={skill.level} 
                        className="h-2"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{skill.level}%</span>
                        <span>Proficiency</span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Skills Overview */}
        <div className="mt-16 max-w-4xl mx-auto">
          <Card className="bg-gradient-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-center">Domain Expertise</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3 text-primary">Machine Learning & Deep Learning</h4>
                  <div className="flex flex-wrap gap-2">
                    {[
                      "Classification Models", "CNN-LSTM", "Transformers", 
                      "Sentiment Analysis", "Feature Engineering", "Hyperparameter Tuning"
                    ].map((skill, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3 text-primary">Data Science & Analytics</h4>
                  <div className="flex flex-wrap gap-2">
                    {[
                      "EDA", "Time Series Analysis", "Statistical Modeling",
                      "Data Visualization", "Backtesting", "Risk Modeling"
                    ].map((skill, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}