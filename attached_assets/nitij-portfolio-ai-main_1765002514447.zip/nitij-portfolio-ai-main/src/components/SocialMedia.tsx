import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Youtube, Instagram, Linkedin, Github, Code, ExternalLink, Play, Users, Eye } from "lucide-react"

export function SocialMedia() {
  // CONFIGURATION: Update these links and stats as needed
  const socialProfiles = [
    {
      platform: "LinkedIn",
      icon: Linkedin,
      handle: "nitij-taneja-702645204",
      link: "https://www.linkedin.com/in/nitij-taneja-702645204/",
      description: "Professional network and career updates",
      stats: { followers: "2500+", posts: "50+" },
      preview: "/api/placeholder/300/200", // TODO: Upload LinkedIn profile preview image
      featuredPosts: [
        "https://www.linkedin.com/posts/nitij-taneja-702645204_nitijtanejamalicious-pickle-poc-hugging-activity-7348024106895732737-lFGz",
        "https://www.linkedin.com/posts/nitij-taneja-702645204_ai-machinelearning-llms-activity-7275076197611372544-mvdL"
      ]
    },
    {
      platform: "YouTube",
      icon: Youtube,
      handle: "@data_science_insights",
      link: "https://youtube.com/@data_science_insights",
      description: "Data Science tutorials and insights",
      stats: { subscribers: "50+", views: "5K+" },
      preview: "/api/placeholder/300/200", // TODO: Upload YouTube channel preview image
      hasVideo: true,
      featuredVideos: [
        "https://youtube.com/shorts/AldeaWzbRwQ?si=xLebEL6gJPelse4M",
        "https://youtube.com/shorts/k9ziR3D8lds?si=UGmNRgnsAztXdtsU"
      ]
    },
    {
      platform: "Instagram",
      icon: Instagram,
      handle: "@data_scienceinsights",
      link: "https://www.instagram.com/data_scienceinsights",
      description: "Short-form data science content and reels",
      stats: { followers: "100+", posts: "10+" },
      preview: "/api/placeholder/300/200", // TODO: Upload Instagram profile preview image
      hasVideo: true
    },
    {
      platform: "GitHub",
      icon: Github,
      handle: "nitij-taneja",
      link: "https://github.com/nitij-taneja",
      description: "Open source projects and repositories",
      stats: { repos: "20+", stars: "100+" },
      preview: "/api/placeholder/300/200", // TODO: Upload GitHub profile preview image
      featuredImage: "https://github.com/nitij-taneja/Blog/blob/main/BLOG4.pdf" // TODO: Replace with actual preview image
    },
    {
      platform: "HackerRank",
      icon: Code,
      handle: "nitij_taneja",
      link: "https://www.hackerrank.com/nitij_taneja",
      description: "Coding challenges and achievements",
      stats: { badges: "3 Gold", rank: "Top 5%" },
      preview: "/api/placeholder/300/200", // TODO: Upload HackerRank profile preview image
      badges: ["Python Gold", "SQL Gold", "C Gold"]
    }
  ]

  const blogPosts = [
    {
      title: "Getting Started with Financial Datasets: A Beginner's Guide",
      platform: "Medium",
      link: "https://medium.com/@tanejanitij4002/getting-started-with-financial-datasets-a-beginners-guide-115404548962",
      preview: "/api/placeholder/300/150", // TODO: Upload Medium article preview image
      readTime: "8 min read"
    },
    {
      title: "Federated Learning Explained: Collaborative AI Without Data Sharing",
      platform: "StackAbuse",
      link: "https://stackabuse.com/federated-learning-explained-collaborative-ai-without-data-sharing/",
      preview: "/api/placeholder/300/150", // TODO: Upload StackAbuse article preview image
      readTime: "12 min read"
    },
    {
      title: "More Medium Articles",
      platform: "Medium Profile", 
      link: "https://medium.com/@tanejanitij4002",
      preview: "/api/placeholder/300/150", // TODO: Upload Medium profile preview image
      readTime: "View All"
    }
  ]

  return (
    <section id="social" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Connect With Me</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Follow my journey across different platforms and read my latest insights
          </p>
        </div>

        {/* Social Profiles */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold mb-8 text-center">Social Profiles</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {socialProfiles.map((profile, index) => (
              <Card key={index} className="bg-gradient-card border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center space-x-3">
                    <profile.icon className="text-primary" size={24} />
                    <span>{profile.platform}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="relative overflow-hidden rounded-lg">
                    {profile.hasVideo ? (
                      <div className="relative">
                        <img 
                          src={profile.preview} 
                          alt={`${profile.platform} preview`}
                          className="w-full h-40 object-cover"
                        />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <Button variant="secondary" size="sm" className="rounded-full">
                            <Play size={16} className="mr-1" />
                            Play
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <img 
                        src={profile.preview} 
                        alt={`${profile.platform} preview`}
                        className="w-full h-40 object-cover"
                      />
                    )}
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-2">{profile.description}</p>
                    <p className="font-mono text-sm text-primary">@{profile.handle}</p>
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <div className="flex space-x-4">
                      {Object.entries(profile.stats).map(([key, value]) => (
                        <div key={key} className="text-center">
                          <div className="font-semibold text-primary">{value}</div>
                          <div className="text-muted-foreground capitalize">{key}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {profile.badges && (
                    <div className="flex flex-wrap gap-2">
                      {profile.badges.map((badge, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs bg-warning/10 text-warning">
                          {badge}
                        </Badge>
                      ))}
                    </div>
                  )}

                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => window.open(profile.link, '_blank')}
                  >
                    <ExternalLink size={16} className="mr-2" />
                    Visit Profile
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Blog Posts */}
        <div>
          <h3 className="text-2xl font-bold mb-8 text-center">Latest Blog Posts</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {blogPosts.map((post, index) => (
              <Card key={index} className="bg-gradient-card border-0 shadow-lg hover:shadow-xl transition-all duration-300 group cursor-pointer">
                <CardContent className="p-0">
                  <div className="relative overflow-hidden">
                    <img 
                      src={post.preview} 
                      alt={post.title}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 right-3">
                      <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                        {post.platform}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-6">
                    <h4 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                      {post.title}
                    </h4>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <span>{post.readTime}</span>
                      <Button variant="ghost" size="sm" onClick={() => window.open(post.link, '_blank')}>
                        <ExternalLink size={14} className="mr-1" />
                        Read
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}