import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, Github, Linkedin, Mail, MapPin, Phone } from "lucide-react"

export function Hero() {
  // CONFIGURATION: Update these links as needed
  const RESUME_URL = "https://drive.google.com/uc?export=download&id=1so3qABVX_3WeqPx7gd80T7x2ocClc2iE"
  
  // Your actual profile images
  const profileImages = [
    "/src/assets/profile-1.jpg",
    "/src/assets/profile-2.jpg",  
    "/src/assets/profile-3.jpg",
    "/src/assets/profile-4.jpg"
  ]

  const handleDownloadResume = () => {
    window.open(RESUME_URL, '_blank')
  }

  const socialLinks = [
    { icon: Github, href: "https://github.com/nitij-taneja", label: "GitHub" },
    { icon: Linkedin, href: "https://www.linkedin.com/in/nitij-taneja-702645204/", label: "LinkedIn" },
    { icon: Mail, href: "mailto:tanejanitij4002@gmail.com", label: "Email" }
  ]

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-hero opacity-10" />
      
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-accent/20 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          {/* Profile Image Carousel */}
          <div className="relative w-40 h-40 mx-auto mb-8 group">
            <div className="absolute inset-0 bg-gradient-primary rounded-full blur-lg opacity-30 group-hover:opacity-50 transition-opacity duration-300 animate-pulse" />
            <div className="relative w-full h-full rounded-full border-4 border-primary/20 overflow-hidden shadow-glow hover:shadow-xl transform hover:scale-105 transition-all duration-300">
              {/* Image carousel container */}
              <div className="relative w-full h-full">
                {profileImages.map((src, index) => (
                  <img 
                    key={index}
                    src={src} 
                    alt={`Nitij Taneja - Profile ${index + 1}`} 
                    className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
                      index === 0 ? 'opacity-100' : 'opacity-0'
                    }`}
                    style={{
                      animationDelay: `${index * 3}s`,
                      animation: profileImages.length > 1 ? `fadeInOut ${profileImages.length * 3}s infinite` : 'none'
                    }}
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                ))}
                {/* Fallback avatar */}
                <div className="absolute inset-0 w-full h-full bg-gradient-primary flex items-center justify-center text-4xl font-bold text-white opacity-0 group-hover:opacity-10 transition-opacity duration-300">
                  NT
                </div>
              </div>
            </div>
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            <span className="block text-foreground">Hi, I'm</span>
            <span className="block bg-gradient-primary bg-clip-text text-transparent break-words">
              Nitij Taneja
            </span>
          </h1>

          {/* Subtitle */}
          <div className="text-xl sm:text-2xl text-muted-foreground mb-8 space-y-2">
            <p>Data Scientist & AI Enthusiast</p>
            <div className="flex items-center justify-center space-x-2 text-lg">
              <MapPin size={18} />
              <span>Bhiwadi, Rajasthan, India</span>
            </div>
          </div>

          {/* Badges */}
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            <Badge variant="secondary" className="text-sm py-2 px-4">
              Machine Learning
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              Deep Learning
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              NLP
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              Django
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              AI
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              Python
            </Badge>
          </div>

          {/* Description */}
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
            4th Year Data Science Student & Jr Data Scientist at Blue Briar Consultancy. 
            Passionate about transforming finance through AI, creating training materials for 
            Langchain & Crew AI, and building innovative solutions in ML, Deep Learning, and NLP.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              size="lg" 
              className="bg-gradient-primary hover:shadow-glow transition-all duration-300"
              onClick={handleDownloadResume}
            >
              <Download className="mr-2" size={20} />
              Download Resume
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300"
              onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
            >
              <Mail className="mr-2" size={20} />
              Get In Touch
            </Button>
          </div>

          {/* Contact Info */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center text-muted-foreground mb-8">
            <div className="flex items-center justify-center space-x-2">
              <Phone size={18} />
              <span>+91-7023108081</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <Mail size={18} />
              <span>tanejanitij4002@gmail.com</span>
            </div>
          </div>

          {/* Social Links */}
          <div className="flex justify-center space-x-6">
            {socialLinks.map((social, index) => (
              <a
                key={index}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-full border border-border hover:border-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-110"
                aria-label={social.label}
              >
                <social.icon size={20} />
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}